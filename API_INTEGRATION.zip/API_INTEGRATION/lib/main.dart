import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'data/repositories/user_repository.dart';
import 'data/services/api_services.dart';
import 'data/services/storage_services.dart';
import 'presentation/screens/home_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final apiService = ApiService();
    final storageService = StorageService();
    final userRepository = UserRepository(
      apiService: apiService,
      storageService: storageService,
    );

    return MaterialApp(
      title: 'User List App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(userRepository: userRepository),
    );
  }
}