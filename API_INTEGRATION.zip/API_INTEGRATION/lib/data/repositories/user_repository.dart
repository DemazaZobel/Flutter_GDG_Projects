import 'package:apiintegrationtask9/data/services/api_services.dart';
import 'package:apiintegrationtask9/data/services/storage_services.dart';
import '../models/user.dart';

class UserRepository {
  final ApiService _apiService;
  final StorageService _storageService;

  UserRepository({
    required ApiService apiService,
    required StorageService storageService,
  })  : _apiService = apiService,
        _storageService = storageService;

  Future<List<User>> fetchUsers() => _apiService.fetchUsers();

  Future<void> saveUser(User user) => _storageService.saveUser(user);

  Future<User?> getSavedUser() => _storageService.getSavedUser();
}