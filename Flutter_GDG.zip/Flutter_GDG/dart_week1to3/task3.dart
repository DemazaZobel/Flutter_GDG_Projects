import 'dart:async';

void main() {
  print("Current time: ${DateTime.now()}");
  
  Future.delayed(Duration(seconds: 5), () {
    print("Time after 5 seconds: ${DateTime.now()}");
  });
}
