// lib/use_cases/create_product.dart

import '../entities/product.dart';

class CreateProductUsecase {
  final List<Product> products;

  CreateProductUsecase(this.products);

  // Method to create a new product
  void call(Product product) {
    products.add(product);
  }
}
