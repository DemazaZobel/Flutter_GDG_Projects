// lib/use_cases/view_product.dart

import '../entities/product.dart';

class ViewProductUsecase {
  final List<Product> products;

  ViewProductUsecase(this.products);

  // Method to retrieve a product by its ID
  Product call(String productId) {
    return products.firstWhere(
      (product) => product.id == productId, 
      orElse: () => Product(
        id: 'default-id', 
        name: 'Product not found', 
        description: 'No product found with the provided ID.', 
        imageUrl: '', 
        price: 0.0
      ),
    );
  }
}
