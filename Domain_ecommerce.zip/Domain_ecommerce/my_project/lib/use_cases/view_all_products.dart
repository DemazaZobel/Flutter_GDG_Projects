// lib/use_cases/view_all_products.dart

import '../entities/product.dart';

class ViewAllProductsUsecase {
  final List<Product> products;

  ViewAllProductsUsecase(this.products);

  
  List<Product> call() {
    return products;
  }
}
