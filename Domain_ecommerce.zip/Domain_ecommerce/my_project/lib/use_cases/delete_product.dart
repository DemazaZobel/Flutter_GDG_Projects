// lib/use_cases/delete_product.dart

import '../entities/product.dart';

class DeleteProductUsecase {
  final List<Product> products;

  DeleteProductUsecase(this.products);

  // Method to delete a product by its ID
  void call(String productId) {
    products.removeWhere((product) => product.id == productId);
  }
}
