// lib/use_cases/update_product.dart

import '../entities/product.dart';

class UpdateProductUsecase {
  final List<Product> products;

  UpdateProductUsecase(this.products);

  // Method to update an existing product
  void call(Product updatedProduct) {
    final productIndex = products.indexWhere((product) => product.id == updatedProduct.id);
    if (productIndex != -1) {
      products[productIndex] = updatedProduct;
    }
  }
}
