

class Product {
  final String id;
  String name;
  String description;
  String imageUrl;
  double price;

  Product({
    required this.id,
    required this.name,
    required this.description,
    required this.imageUrl,
    required this.price,
  });

  // Method to convert Product to String for easy display
  @override
  String toString() {
    return 'Product{id: $id, name: $name, description: $description, imageUrl: $imageUrl, price: $price}';
  }
}
