class Laptop {
  int id;
  String name;
  int ram;

  Laptop(this.id, this.name, this.ram);

  void printDetails() {
    print("ID: $id, Name: $name, RAM: ${ram}GB");
  }
}

void main() {
  
  Laptop laptop1 = Laptop(101, "Dell", 8);
  Laptop laptop2 = Laptop(102, "HP", 16);
  Laptop laptop3 = Laptop(103, "MacBook", 32);

  
  laptop1.printDetails();
  laptop2.printDetails();
  laptop3.printDetails();
}
