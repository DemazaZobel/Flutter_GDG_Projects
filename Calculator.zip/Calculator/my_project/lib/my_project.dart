import 'dart:io';
import 'dart:math';

class Calculator {
  double add(double a, double b) => a + b;
  double subtract(double a, double b) => a - b;
  double multiply(double a, double b) => a * b;
  
  double divide(double a, double b) {
    if (b == 0) {
      throw Exception('Cannot divide by zero.');
    }
    return a / b;
  }

  double modulus(double a, double b) {
    if (b == 0) {
      throw Exception('Cannot perform modulus by zero.');
    }
    return a % b;
  }

  double power(double base, double exponent) => pow(base, exponent).toDouble();
}

void main() async {
  Calculator calculator = Calculator();

  while (true) {
    try {
      stdout.write('Enter first number: ');
      double num1 = double.parse(stdin.readLineSync()!);

      stdout.write('Enter an operator (+, -, *, /, %, ^): ');
      String operator = stdin.readLineSync()!;

      stdout.write('Enter second number: ');
      double num2 = double.parse(stdin.readLineSync()!);

      double result;
      switch (operator) {
        case '+':
          result = calculator.add(num1, num2);
          break;
        case '-':
          result = calculator.subtract(num1, num2);
          break;
        case '*':
          result = calculator.multiply(num1, num2);
          break;
        case '/':
          result = calculator.divide(num1, num2);
          break;
        case '%':
          result = calculator.modulus(num1, num2);
          break;
        case '^':
          result = calculator.power(num1, num2);
          break;
        default:
          throw Exception('Invalid operator!');
      }

      print('Calculating...');
      await Future.delayed(Duration(seconds: 5));
      print('Result: $result');

    } catch (e) {
      print('Error: ${e.toString()}');
    }
  }
}
