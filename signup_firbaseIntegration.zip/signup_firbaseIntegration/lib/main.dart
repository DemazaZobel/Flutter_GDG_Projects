import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}


class AuthCubit extends Cubit<Map<String, dynamic>> {
  AuthCubit() : super({'passwordVisible': false, 'email': '', 'password': ''});

  void togglePasswordVisibility() {
    emit({...state, 'passwordVisible': !state['passwordVisible']});
  }

  void updateEmail(String email) {
    emit({...state, 'email': email});
  }

  void updatePassword(String password) {
    emit({...state, 'password': password});
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => AuthCubit(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        initialRoute: '/signup',
        routes: {
          '/signup': (context) => SignUpPage(),
          '/signin': (context) => SignInPage(),
          '/home': (context) => HomePage(),
        },
      ),
    );
  }
}

class SignUpPage extends StatelessWidget {
  // Create a FirebaseAuth instance
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Create New Account",
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                SizedBox(height: 20),
                TextField(
                  decoration: InputDecoration(labelText: "Full Name"),
                ),
                BlocBuilder<AuthCubit, Map<String, dynamic>>(
                  builder: (context, state) {
                    return TextField(
                      obscureText: !state['passwordVisible'],
                      decoration: InputDecoration(
                        labelText: "Password",
                        suffixIcon: IconButton(
                          icon: Icon(state['passwordVisible']
                              ? Icons.visibility
                              : Icons.visibility_off),
                          onPressed: () =>
                              context.read<AuthCubit>().togglePasswordVisibility(),
                        ),
                      ),
                      onChanged: (value) =>
                          context.read<AuthCubit>().updatePassword(value),
                    );
                  },
                ),
                TextField(
                  decoration: InputDecoration(labelText: "Email"),
                  onChanged: (value) =>
                      context.read<AuthCubit>().updateEmail(value),
                ),
                TextField(
                  decoration: InputDecoration(labelText: "Mobile Number"),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () async {
                    // Get email and password from state
                    final email = context.read<AuthCubit>().state['email'];
                    final password = context.read<AuthCubit>().state['password'];
                    try {
                      // Create user with Firebase
                      await _auth.createUserWithEmailAndPassword(
                          email: email, password: password);
                      // After a successful sign up, navigate to Sign In page
                      Navigator.pushNamed(context, '/signin');
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Sign Up Error: $e")),
                      );
                    }
                  },
                  child: Text("Sign Up"),
                  style: ElevatedButton.styleFrom(
                      minimumSize: Size(double.infinity, 50)),
                ),
                SizedBox(height: 10),
                BlocBuilder<AuthCubit, Map<String, dynamic>>(
                  builder: (context, state) {
                    return Text("Email: ${state['email']}\nPassword: ${state['password']}");
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SignInPage extends StatelessWidget {
  // Create a FirebaseAuth instance
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Sign In",
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                SizedBox(height: 20),
                TextField(
                  decoration: InputDecoration(labelText: "Email"),
                  onChanged: (value) =>
                      context.read<AuthCubit>().updateEmail(value),
                ),
                BlocBuilder<AuthCubit, Map<String, dynamic>>(
                  builder: (context, state) {
                    return TextField(
                      obscureText: !state['passwordVisible'],
                      decoration: InputDecoration(
                        labelText: "Password",
                        suffixIcon: IconButton(
                          icon: Icon(state['passwordVisible']
                              ? Icons.visibility
                              : Icons.visibility_off),
                          onPressed: () =>
                              context.read<AuthCubit>().togglePasswordVisibility(),
                        ),
                      ),
                      onChanged: (value) =>
                          context.read<AuthCubit>().updatePassword(value),
                    );
                  },
                ),
                SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text("Forgot Password?"),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () async {
                    // Get email and password from state
                    final email = context.read<AuthCubit>().state['email'];
                    final password = context.read<AuthCubit>().state['password'];
                    try {
                      // Sign in with Firebase
                      await _auth.signInWithEmailAndPassword(
                          email: email, password: password);
                      // Navigate to Home on success
                      Navigator.pushNamed(context, '/home');
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Sign In Error: $e")),
                      );
                    }
                  },
                  child: Text("Sign In"),
                  style: ElevatedButton.styleFrom(
                      minimumSize: Size(double.infinity, 50)),
                ),
                SizedBox(height: 10),
                BlocBuilder<AuthCubit, Map<String, dynamic>>(
                  builder: (context, state) {
                    return Text("Email: ${state['email']}\nPassword: ${state['password']}");
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text("Welcome to Home Page!"),
      ),
    );
  }
}
