import 'product.dart';

class ProductManager {
  List<Product> _products = [];

  void addProduct(Product product) {
    _products.add(product);
    print('Product added successfully!');
  }

  void viewAllProducts() {
    if (_products.isEmpty) {
      print('No products available.');
    } else {
      _products.forEach((product) {
        print(product);
      });
    }
  }

  void viewProduct(String name) {
    // If no product found, throws an exception instead of returning null
    try {
      Product product = _products.firstWhere(
        (product) => product.name.toLowerCase() == name.toLowerCase(),
      );
      print(product);
    } catch (e) {
      print('Product not found.');
    }
  }

  void editProduct(String name, String newName, String newDescription, double newPrice) {
    try {
      Product product = _products.firstWhere(
        (product) => product.name.toLowerCase() == name.toLowerCase(),
      );
      product.name = newName;
      product.description = newDescription;
      product.price = newPrice;
      print('Product updated successfully!');
    } catch (e) {
      print('Product not found.');
    }
  }

  void deleteProduct(String name) {
    try {
      Product product = _products.firstWhere(
        (product) => product.name.toLowerCase() == name.toLowerCase(),
      );
      _products.remove(product);
      print('Product deleted successfully!');
    } catch (e) {
      print('Product not found.');
    }
  }
}
